// components/PayrollManagement.jsx
import React, { useState, useEffect } from 'react';
import Modal from '../../components/common/Modal';

const AdminPayrollManagement = () => {

    const [loading, setLoading] = useState(false);

  // Static payroll data
  const staticPayrolls = [
    {
      id: 1,
      month: 'January 2024',
      employeeCount: 45,
      totalSalary: 2250000,
      status: 'processed',
      processedDate: '2024-01-31',
      employeeName: 'All Employees'
    },
    {
      id: 2,
      month: 'December 2023',
      employeeCount: 43,
      totalSalary: 2150000,
      status: 'processed',
      processedDate: '2023-12-30',
      employeeName: 'All Employees'
    },
    {
      id: 3,
      month: 'November 2023',
      employeeCount: 42,
      totalSalary: 2100000,
      status: 'processed',
      processedDate: '2023-11-30',
      employeeName: 'All Employees'
    },
    {
      id: 4,
      month: 'February 2024',
      employeeCount: 46,
      totalSalary: 2300000,
      status: 'pending',
      processedDate: null,
      employeeName: 'All Employees'
    }
  ];

  // Static employee data for payroll generation
  const staticEmployees = [
    { 
      id: 1, 
      name: 'John Doe', 
      basicSalary: 50000, 
      department: 'Engineering',
      bankAccount: 'XXXX-XXXX-1234'
    },
    { 
      id: 2, 
      name: 'Jane Smith', 
      basicSalary: 60000, 
      department: 'Sales',
      bankAccount: 'XXXX-XXXX-5678'
    },
    { 
      id: 3, 
      name: 'Bob Johnson', 
      basicSalary: 45000, 
      department: 'Marketing',
      bankAccount: 'XXXX-XXXX-9012'
    },
    { 
      id: 4, 
      name: 'Alice Brown', 
      basicSalary: 55000, 
      department: 'HR',
      bankAccount: 'XXXX-XXXX-3456'
    },
    { 
      id: 5, 
      name: 'Charlie Wilson', 
      basicSalary: 70000, 
      department: 'Engineering',
      bankAccount: 'XXXX-XXXX-7890'
    }
  ];

  const [payrolls, setPayrolls] = useState([]);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [showStructureModal, setShowStructureModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedPayroll, setSelectedPayroll] = useState(null);
  
  const [salaryStructure, setSalaryStructure] = useState({
    basic: '40',
    hra: '20',
    da: '10',
    specialAllowance: '15',
    medical: '5',
    conveyance: '5',
    pf: '12',
    esic: '3.25',
    tds: '10'
  });

  const [generateData, setGenerateData] = useState({
    month: '',
    year: '',
    includeBonuses: true,
    includeDeductions: true
  });

  const [editData, setEditData] = useState({
    month: '',
    employeeCount: '',
    totalSalary: '',
    status: 'pending'
  });

  const [filterMonth, setFilterMonth] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    fetchPayrolls();
  }, []);

  // CRUD Operations
  const fetchPayrolls = () => {
    setLoading(true);
    setTimeout(() => {
      setPayrolls(staticPayrolls);
      setLoading(false);
    }, 500);
  };

  // CREATE - Generate new payroll
  const handleGeneratePayroll = () => {
    if (!generateData.month || !generateData.year) {
      alert('Please select month and year');
      return;
    }

    const monthName = new Date(`${generateData.month} 1, ${generateData.year}`)
      .toLocaleString('en', { month: 'long' });
    const monthYear = `${monthName} ${generateData.year}`;
    
    // Check if payroll already exists for this month
    const existingPayroll = payrolls.find(p => p.month === monthYear);
    if (existingPayroll) {
      alert('Payroll for this month already exists!');
      return;
    }

    // Calculate total salary
    const totalSalary = staticEmployees.reduce((sum, emp) => {
      const salary = calculateSalary(emp.basicSalary);
      return sum + salary.net;
    }, 0);

    const newPayroll = {
      id: payrolls.length + 1,
      month: monthYear,
      employeeCount: staticEmployees.length,
      totalSalary: totalSalary,
      status: 'pending',
      processedDate: new Date().toISOString().split('T')[0],
      employeeName: 'All Employees'
    };

    setPayrolls([newPayroll, ...payrolls]);
    setShowGenerateModal(false);
    
    // Reset form
    setGenerateData({
      month: '',
      year: '',
      includeBonuses: true,
      includeDeductions: true
    });
    
    alert('Payroll generated successfully!');
  };

  // READ - Get payroll by ID
  const getPayrollById = (id) => {
    return payrolls.find(p => p.id === id);
  };

  // UPDATE - Edit payroll
  const handleEditPayroll = (payroll) => {
    setSelectedPayroll(payroll);
    setEditData({
      month: payroll.month,
      employeeCount: payroll.employeeCount,
      totalSalary: payroll.totalSalary,
      status: payroll.status
    });
    setShowEditModal(true);
  };

  const handleUpdatePayroll = () => {
    setPayrolls(payrolls.map(p => 
      p.id === selectedPayroll.id 
        ? { 
            ...p, 
            ...editData,
            totalSalary: parseFloat(editData.totalSalary)
          } 
        : p
    ));
    
    setShowEditModal(false);
    setSelectedPayroll(null);
    alert('Payroll updated successfully!');
  };

  const updatePayrollStatus = (id, newStatus) => {
    setPayrolls(payrolls.map(p => 
      p.id === id ? { ...p, status: newStatus } : p
    ));
  };

  // DELETE - Remove payroll
  const deletePayroll = (id) => {
    if (window.confirm('Are you sure you want to delete this payroll?')) {
      setPayrolls(payrolls.filter(p => p.id !== id));
      alert('Payroll deleted successfully!');
    }
  };

  // Calculate salary components
  const calculateSalary = (basicSalary) => {
    const basic = (basicSalary * salaryStructure.basic) / 100;
    const hra = (basicSalary * salaryStructure.hra) / 100;
    const da = (basicSalary * salaryStructure.da) / 100;
    const specialAllowance = (basicSalary * salaryStructure.specialAllowance) / 100;
    const medical = (basicSalary * salaryStructure.medical) / 100;
    const conveyance = (basicSalary * salaryStructure.conveyance) / 100;
    
    const gross = basic + hra + da + specialAllowance + medical + conveyance;
    
    const pf = (basicSalary * salaryStructure.pf) / 100;
    const esic = (basicSalary * salaryStructure.esic) / 100;
    const tds = (basicSalary * salaryStructure.tds) / 100;
    
    const deductions = pf + esic + tds;
    const net = gross - deductions;
    
    return { gross, deductions, net, basic, hra, da, specialAllowance, medical, conveyance, pf, esic, tds };
  };

  const handleSaveStructure = () => {
    // Save to localStorage (simulated)
    localStorage.setItem('salaryStructure', JSON.stringify(salaryStructure));
    alert('Salary structure saved successfully!');
    setShowStructureModal(false);
  };

  const handleDownloadSlip = (payroll) => {
    // Generate PDF content
    const payrollDetails = `
      Payroll Month: ${payroll.month}
      Employee Count: ${payroll.employeeCount}
      Total Salary: ₹${payroll.totalSalary.toLocaleString()}
      Status: ${payroll.status}
      Processed Date: ${payroll.processedDate || 'N/A'}
      Generated On: ${new Date().toLocaleDateString()}
    `;

    // Simulate PDF download
    const blob = new Blob([payrollDetails], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payroll-${payroll.month.toLowerCase().replace(' ', '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    alert(`Downloading payroll summary for ${payroll.month}`);
  };

  const handleSendSlip = (payroll) => {
    // Simulate sending email
    alert(`Payslip for ${payroll.month} sent to all employees!`);
    updatePayrollStatus(payroll.id, 'sent');
  };

  // Get status color
  const getStatusColor = (status) => {
    switch(status) {
      case 'processed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Filter payrolls
  const filteredPayrolls = payrolls.filter(payroll => {
    if (filterMonth && !payroll.month.toLowerCase().includes(filterMonth.toLowerCase())) {
      return false;
    }
    if (filterStatus && payroll.status !== filterStatus) {
      return false;
    }
    return true;
  });

  // Get months for dropdown
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const years = [2023, 2024, 2025];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Payroll Management</h2>
            <p className="text-gray-600">Manage employee salaries and payroll processing</p>
          </div>
          <div className="flex space-x-3 mt-4 md:mt-0">
            <button
              onClick={() => setShowStructureModal(true)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              ⚙️ Salary Structure
            </button>
            <button
              onClick={() => setShowGenerateModal(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              💰 Generate Payroll
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <div className="text-sm text-gray-600">Total Payrolls</div>
            <div className="text-2xl font-bold text-gray-900">{payrolls.length}</div>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <div className="text-sm text-gray-600">Total Salary</div>
            <div className="text-2xl font-bold text-green-600">
              ₹{payrolls.reduce((sum, p) => sum + p.totalSalary, 0).toLocaleString()}
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <div className="text-sm text-gray-600">Processed</div>
            <div className="text-2xl font-bold text-blue-600">
              {payrolls.filter(p => p.status === 'processed').length}
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <div className="text-sm text-gray-600">Pending</div>
            <div className="text-2xl font-bold text-yellow-600">
              {payrolls.filter(p => p.status === 'pending').length}
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
            <div className="flex space-x-4">
              <input
                type="text"
                value={filterMonth}
                onChange={(e) => setFilterMonth(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Filter by month (e.g., January)"
              />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="">All Status</option>
                <option value="processed">Processed</option>
                <option value="pending">Pending</option>
                <option value="sent">Sent</option>
              </select>
              <button
                onClick={() => {
                  setFilterMonth('');
                  setFilterStatus('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Payroll List */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Payroll History</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Month</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee Count</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Salary</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Processed On</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredPayrolls.map((payroll) => (
                  <tr key={payroll.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap font-medium">
                      {payroll.month}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {payroll.employeeCount}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-bold">
                      ₹{payroll.totalSalary?.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-3 py-1 text-sm rounded-full ${getStatusColor(payroll.status)}`}>
                        {payroll.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {payroll.processedDate || '--'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleDownloadSlip(payroll)}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg text-sm hover:bg-blue-200"
                        >
                          Download
                        </button>
                        <button
                          onClick={() => handleSendSlip(payroll)}
                          className="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200"
                        >
                          Send
                        </button>
                        <button
                          onClick={() => handleEditPayroll(payroll)}
                          className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-lg text-sm hover:bg-yellow-200"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => deletePayroll(payroll.id)}
                          className="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-sm hover:bg-red-200"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Employee Salary Preview */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Employee Salary Breakdown</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Basic Salary</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gross Salary</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Deductions</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Net Salary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {staticEmployees.map((employee) => {
                  const salary = calculateSalary(employee.basicSalary);
                  return (
                    <tr key={employee.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap font-medium">
                        {employee.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {employee.department}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        ₹{employee.basicSalary.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-bold text-green-600">
                        ₹{salary.gross.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-bold text-red-600">
                        -₹{salary.deductions.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-bold text-blue-600">
                        ₹{salary.net.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Salary Structure Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Earnings Structure</h3>
            <div className="space-y-3">
              {Object.entries(salaryStructure).filter(([key]) => 
                !['pf', 'esic', 'tds'].includes(key)
              ).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center">
                  <span className="text-gray-700 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-medium">{value}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Deductions Structure</h3>
            <div className="space-y-3">
              {Object.entries(salaryStructure).filter(([key]) => 
                ['pf', 'esic', 'tds'].includes(key)
              ).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center">
                  <span className="text-gray-700 uppercase">{key}</span>
                  <span className="font-medium text-red-600">{value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Generate Payroll Modal */}
        <Modal
          show={showGenerateModal}
          onClose={() => setShowGenerateModal(false)}
          title="Generate Payroll"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Month *
                </label>
                <select
                  value={generateData.month}
                  onChange={(e) => setGenerateData({...generateData, month: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="">Select Month</option>
                  {months.map((month, i) => (
                    <option key={i} value={month}>{month}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Year *
                </label>
                <select
                  value={generateData.year}
                  onChange={(e) => setGenerateData({...generateData, year: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="">Select Year</option>
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">Options</h4>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeBonuses"
                  checked={generateData.includeBonuses}
                  onChange={(e) => setGenerateData({...generateData, includeBonuses: e.target.checked})}
                  className="h-4 w-4 text-blue-600 rounded"
                />
                <label htmlFor="includeBonuses" className="ml-2 text-sm text-gray-700">
                  Include performance bonuses
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeDeductions"
                  checked={generateData.includeDeductions}
                  onChange={(e) => setGenerateData({...generateData, includeDeductions: e.target.checked})}
                  className="h-4 w-4 text-blue-600 rounded"
                />
                <label htmlFor="includeDeductions" className="ml-2 text-sm text-gray-700">
                  Include tax deductions
                </label>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-yellow-800">
                ⚠️ This will generate payroll for {staticEmployees.length} active employees for the selected period.
                Total estimated salary: ₹{staticEmployees.reduce((sum, emp) => sum + calculateSalary(emp.basicSalary).net, 0).toLocaleString()}
              </p>
            </div>
          </div>

          <div className="mt-6 flex justify-end space-x-3">
            <button
              onClick={() => setShowGenerateModal(false)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleGeneratePayroll}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Generate Payroll
            </button>
          </div>
        </Modal>

        {/* Salary Structure Modal */}
        <Modal
          show={showStructureModal}
          onClose={() => setShowStructureModal(false)}
          title="Salary Structure Configuration"
          size="lg"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Object.entries(salaryStructure).map(([key, value]) => (
                <div key={key}>
                  <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
                    {key.replace(/([A-Z])/g, ' $1')} (%)
                  </label>
                  <input
                    type="number"
                    value={value}
                    onChange={(e) => {
                      const newValue = parseFloat(e.target.value);
                      if (newValue >= 0 && newValue <= 100) {
                        setSalaryStructure({...salaryStructure, [key]: e.target.value});
                      }
                    }}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    step="0.01"
                    min="0"
                    max="100"
                  />
                </div>
              ))}
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">Sample Calculation (Basic Salary: ₹50,000)</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Basic Salary:</span>
                  <span>₹50,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Gross Salary:</span>
                  <span>₹{calculateSalary(50000).gross.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Deductions:</span>
                  <span className="text-red-600">-₹{calculateSalary(50000).deductions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-gray-200 pt-2">
                  <span>Net Salary:</span>
                  <span className="text-green-600">₹{calculateSalary(50000).net.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-end space-x-3">
            <button
              onClick={() => setShowStructureModal(false)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveStructure}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Save Structure
            </button>
          </div>
        </Modal>

        {/* Edit Payroll Modal */}
        <Modal
          show={showEditModal}
          onClose={() => setShowEditModal(false)}
          title="Edit Payroll"
        >
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Month *</label>
              <input
                type="text"
                value={editData.month}
                onChange={(e) => setEditData({...editData, month: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="e.g., January 2024"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Employee Count *</label>
                <input
                  type="number"
                  value={editData.employeeCount}
                  onChange={(e) => setEditData({...editData, employeeCount: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  min="1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Total Salary *</label>
                <input
                  type="number"
                  value={editData.totalSalary}
                  onChange={(e) => setEditData({...editData, totalSalary: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  min="0"
                  step="1000"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select
                value={editData.status}
                onChange={(e) => setEditData({...editData, status: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="pending">Pending</option>
                <option value="processed">Processed</option>
                <option value="sent">Sent</option>
              </select>
            </div>

            <div className="mt-6 flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <button
                onClick={() => setShowEditModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdatePayroll}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Update Payroll
              </button>
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default AdminPayrollManagement;